var app = angular.module('app',[]);
app.controller('MultiplicationTableCtrl', function() {
	this.rows = [
		[ 1, 1, 1, 1 ],
		[ 1, 1, 1, 1 ],
		[ 1, 1, 1, 1 ],
		[ 1, 1, 1, 1 ]
	];
});